package com.interest.model.entity;

import lombok.Data;

/**
 * @author wanghuan
 */
@Data
public class UserQQEntity {

    private String openid;

    private String nickname;

    private String figureurlQq1;

    private String gender;

    private Integer userid;

}
