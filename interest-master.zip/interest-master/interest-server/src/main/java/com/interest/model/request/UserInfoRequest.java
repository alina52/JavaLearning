package com.interest.model.request;

import com.interest.model.response.UserInfoResponse;
import lombok.Data;

@Data
public class UserInfoRequest extends UserInfoResponse {

}
