package com.interest.login.exception;

public class LoginFailureExcepiton extends RuntimeException {

	private static final long serialVersionUID = 1381277361046202535L;

	public LoginFailureExcepiton(String message) {
		super(message);
	}
	
}
