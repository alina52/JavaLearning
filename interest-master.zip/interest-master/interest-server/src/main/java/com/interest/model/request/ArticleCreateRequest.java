package com.interest.model.request;

import lombok.Data;

@Data
public class ArticleCreateRequest {

    private String title;

    private String content;

}
