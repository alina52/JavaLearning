package com.interest.model.ordinary;

import lombok.Data;

@Data
public class UserIdHeadImg {

    private Integer id;

    private String headImage;

}
