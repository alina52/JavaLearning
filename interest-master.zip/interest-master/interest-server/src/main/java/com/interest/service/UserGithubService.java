package com.interest.service;

import com.interest.model.entity.UserGithubEntity;

public interface UserGithubService {

	void insertEntity(UserGithubEntity userGithubEntity);
}
