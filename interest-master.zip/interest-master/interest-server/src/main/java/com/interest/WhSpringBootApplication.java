package com.interest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhSpringBootApplication.class, args);
	}
}
