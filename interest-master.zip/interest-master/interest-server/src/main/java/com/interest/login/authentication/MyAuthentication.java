package com.interest.login.authentication;

public interface MyAuthentication {
	
	public String getUserId(String code);
	
}
