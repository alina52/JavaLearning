package com.interest.model.response;

import lombok.Data;

@Data
public class InterestResponse {

    private Integer id;

    private String title;

    private String info;

    private String image;

}
