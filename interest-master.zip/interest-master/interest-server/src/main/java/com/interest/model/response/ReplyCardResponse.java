package com.interest.model.response;

import lombok.Data;

@Data
public class ReplyCardResponse {

    private String headimg;

    private String githuburl;

    private String username;

    private Integer id;

    private String content;

    private Integer postcardid;

    private String createtime;

    private Integer userid;
}
