package com.interest.service;

import com.interest.model.entity.UserQQEntity;

public interface UserQQService {

	void insertEntity(UserQQEntity userQQEntity);
}
