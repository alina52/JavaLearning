package com.interest.model.response;

import lombok.Data;

@Data
public class BannerResponse {
    private Integer id;

    private String image;

}
