# interest

## 项目介绍
  该项目为前后端分离项目，前端vue，后端Spring boot。
  
## 已有功能介绍
1. pc版展示页面。
2. mobile版展示页面。
3. pc版后台管理系统。
4. github,QQ第三方登录。
5. oauth2授权与认证。
  
## 项展示
  项目展示地址为我的网站：http://www.lovemtt.com/ （服务器配置低，首次加载会有点慢，登录请用github第三方登录。）

## 项目结构
- 前端源码是该目录下的interest-web，前端详细介绍地址：https://github.com/smallsnail-wh/interest/tree/master/interest-web
- 后端源码是该目录下的interest-server，后端详细介绍地址：https://github.com/smallsnail-wh/interest/tree/master/interest-server

## 该项目的微服务版
https://github.com/smallsnail-wh/interest-pro
